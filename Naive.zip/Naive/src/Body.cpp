#include "Body.h"

Body::Body(double x, double y, double z, double mass) : x(x), y(y), z(z), mass(mass) {

}

Body::~Body() {

}
