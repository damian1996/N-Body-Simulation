#ifndef STEPNAIVECUDA_H
#define STEPNAIVECUDA_H

#include "RandomGenerators.h"

#include "Step.h"
#include "ComputationsCuda.h"

class StepNaiveCuda : public Step {
public:
    thrust::host_vector<float> velocities;
    thrust::host_vector<float> weights;
    RandomGenerators* rg;
    StepNaiveCuda(unsigned N);
    ~StepNaiveCuda();
    void initialize();
    void compute(tf3& positions, float dt);
};

#endif
