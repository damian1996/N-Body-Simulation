#ifndef WDGK_OPENGL_GL
#define WDGK_OPENGL_GL

#define GL_GLEXT_PROTOTYPES 1
#define GL3_PROTOTYPES 1
#include <GLFW/glfw3.h>

#endif
