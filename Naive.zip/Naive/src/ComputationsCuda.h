#ifndef CUDASTEP_H
#define CUDASTEP_H

#include <thrust/host_vector.h>
#include <thrust/device_vector.h>

typedef thrust::host_vector<float> type;

thrust::device_vector<float> veloD;
thrust::device_vector<float> weightsD;

class Computations {
public:
  static void initData(type& velocities, type& weights);
  //void NaiveSimBridge(Render* painter, type& pos, type& velocities, type& weights, int N);
  static void NaiveSimBridgeThrust(type& pos, int N, float dt);
private:
  Computations() {}
};

#endif
