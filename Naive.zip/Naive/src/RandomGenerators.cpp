#include "RandomGenerators.h"

RandomGenerators::RandomGenerators() {}

float RandomGenerators::getRandomFloat(float a, float b) {
  std::random_device rd1;
  std::mt19937 gen1(rd1());
  std::uniform_real_distribution<> disfloat(a, b);
  return disfloat(gen1);
}

int RandomGenerators::getRandomColor() {
  std::random_device rd2;
  std::mt19937 gen2(rd2());
  std::uniform_int_distribution<> disByte(100, 255);
  return disByte(gen2);
}

int RandomGenerators::getRandomType() {
  std::random_device rd3;
  std::mt19937 gen3(rd3());
  std::uniform_int_distribution<> disInt(0, 3);
  return disInt(gen3);
}

template <typename T>
void RandomGenerators::initializeVelocities(T &velocities, unsigned N) {}

template <>
void RandomGenerators::initializeVelocities<std::vector<float>>(
    std::vector<float> &velocities, unsigned numberOfBodies) {
  velocities.resize(3 * numberOfBodies);

  for (unsigned i = 0; i < numberOfBodies; i++)
    for (int j = 0; j < 3; j++)
      velocities[i * 3 + j] = getRandomFloat(-0.01, 0.01);
      //velocities[i * 3 + j] = getRandomFloat(-0.01f, 0.01f);
}

template <>
void RandomGenerators::initializeVelocities<std::vector<double>>(
    std::vector<double> &velocities, unsigned numberOfBodies) {
  velocities.resize(3 * numberOfBodies);

  for (unsigned i = 0; i < numberOfBodies; i++)
    for (int j = 0; j < 3; j++)
      velocities[i * 3 + j] = getRandomFloat(-0.01, 0.01);
      //velocities[i * 3 + j] = getRandomFloat(-0.01, 0.01);
}

// zderzenie plastyczne / sprezyste
template <>
void RandomGenerators::initializeVelocities<thrust::host_vector<float>>(
    thrust::host_vector<float> &velocities, unsigned numberOfBodies) {
  velocities.resize(3 * numberOfBodies);
  for (unsigned i = 0; i < numberOfBodies; i++)
    for (int j = 0; j < 3; j++)
      velocities[i * 3 + j] = getRandomFloat(-0.01f, 0.01f);
}

void RandomGenerators::initializeWeights(std::vector<float> &weights, unsigned numberOfBodies) {
  weights.resize(numberOfBodies);
  int typeMass = 1; //getRandomType();
  unsigned divi;
  printf("TYP %d\n", typeMass);
  switch (typeMass) {
  case 0: // full random
    for (unsigned i = 0; i < numberOfBodies; i++)
      weights[i] = getRandomFloat(1000.0f, 100000.0f); // 10^10
    break;
  case 1: // 1/10 duze masy, reszta stosunkowo male
    divi = static_cast<unsigned>(numberOfBodies/100);
    for (unsigned i = 0; i < divi; i++)
      weights[i] = getRandomFloat(1000000.0f, 1010000.0f);
    for (unsigned i = divi; i < numberOfBodies; i++)
      weights[i] = getRandomFloat(10000.0f, 20000.0f);
    break;
  case 2: // 1/20 male, 2/10 duze, 5/15 male
    divi = static_cast<unsigned>(numberOfBodies/20);
    for (unsigned i = 0; i < divi; i++)
      weights[i] = getRandomFloat(1000000.0f, 1010000.0f);
    for (unsigned i = divi; i < 5 * divi; i++)
      weights[i] = getRandomFloat(40000.0f, 45000.0f);
    for (unsigned i = 5 * divi; i < numberOfBodies; i++)
      weights[i] = getRandomFloat(1000.0f, 2000.0f);
    break;
  default: // same male
    for (unsigned i = 0; i < numberOfBodies; i++)
      weights[i] = getRandomFloat(1000.0f, 1100.0f); // 10^10
    break;
  }
}
// zderzenie plastyczne / sprezyste
